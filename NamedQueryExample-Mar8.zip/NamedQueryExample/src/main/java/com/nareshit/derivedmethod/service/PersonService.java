package com.nareshit.derivedmethod.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nareshit.derivedmethod.dao.BookDao;
import com.nareshit.derivedmethod.dao.EmployeeDao;
import com.nareshit.derivedmethod.dao.PersonDao;
import com.nareshit.derivedmethod.model.Book;
import com.nareshit.derivedmethod.model.Employee;
import com.nareshit.derivedmethod.model.Person;

@Service
public class PersonService {

	@Autowired
	private PersonDao personDao;

	@Autowired
	private BookDao bookDao;


	@Autowired
	private EmployeeDao empDao;


//Collection API are provided by CRUD REPOSTIRY LIKE SaveAll , findAllById

	public Iterable<Person> savePersons(Iterable<Person> personsList){

		return personDao.saveAll(personsList);

		/*
		 * saveAll ==> forreach{obj in [])
		 * {		obj.save()
		 * }
		 */
	}


	//Retreving more than one Primary Key

	public Iterable<Person> getPersonsData(Iterable<Integer> personIds){
		return personDao.findAllById(personIds);

		/*
		 * findAllById ==>select * from table where primarykey in (1,2,3,4,5....)
		 */
	}


	public Iterable<Person> findByLastName(String lastName){
		return personDao.findByLastName(lastName);
	}

	public Person findByLastNameAndFirstName(String lastName,String firstName){
		return personDao.findByLastNameAndFirstName(lastName, firstName);
	}

	public Iterable<Person> findByLastNameOrderByCreatedDateDesc(String lastName){
		return personDao.findByLastNameOrderByCreatedDateDesc(lastName);
	}


	public Iterable<Person> findByLastNameOrFirstName(String lastName,String firstName){
		return personDao.findByLastNameOrFirstName(lastName, firstName);
	}


	public Iterable<Person> findByAgeLessThanEqual(Integer personAge){
		return personDao.findByAgeLessThanEqual(personAge);
	}

	public Iterable<Person> findByFirstNameLike(String firstName){
		return personDao.findByFirstNameLike(firstName);
	}

	public Iterable<Person> findByLastNameAndAgeLessThanEqual(String lastName,int personAge){
		return personDao.findByLastNameAndAgeLessThanEqual(lastName, personAge);
	}

	public Iterable<Person> findByCreatedDateBetween(Date startdate,Date endDate){
		return personDao.findByCreatedDateBetween(startdate, endDate);
	}

	public Iterable<Person> givePersonData(String lastName){
		return personDao.givePersonData(lastName);
	}

	public Iterable<Book> saveAllBooks(Iterable<Book> booksData){

		return bookDao.saveAll(booksData);

	}

	public Iterable<Book> getAllBooks(){
		return bookDao.findAll();
	}

	public Iterable<Book> fetchBookByName(String bookName){
		return bookDao.fetchBookByName(bookName);
	}

	public Iterable<Employee> saveAllEmployees(Iterable<Employee> empList){
		return empDao.saveAll(empList);
	}

	public List<Object[]> findMaxSalariesByDept(List<String> deptNames){
		return empDao.findMaxSalariesByDept(deptNames);
	}
	public Iterable<Person> giveFewColumns(String lastName){
		return personDao.giveFewColumns(lastName);
	}
}

