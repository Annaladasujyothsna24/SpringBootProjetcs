package com.nareshit.derivedmethod.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nareshit.derivedmethod.dao.PersonDao;
import com.nareshit.derivedmethod.model.Person;

@Service
public class PersonService {

	@Autowired
	private PersonDao personDao;


//Collection API are provided by CRUD REPOSTIRY LIKE SaveAll , findAllById

	public Iterable<Person> savePersons(Iterable<Person> personsList){

		return personDao.saveAll(personsList);

		/*
		 * saveAll ==> forreach{obj in [])
		 * {		obj.save()
		 * }
		 */
	}


	//Retreving more than one Primary Key

	public Iterable<Person> getPersonsData(Iterable<Integer> personIds){
		return personDao.findAllById(personIds);

		/*
		 * findAllById ==>select * from table where primarykey in (1,2,3,4,5....)
		 */
	}


	public Iterable<Person> findByLastName(String lastName){
		return personDao.findByLastName(lastName);
	}

	public Person findByLastNameAndFirstName(String lastName,String firstName){
		return personDao.findByLastNameAndFirstName(lastName, firstName);
	}

	public Iterable<Person> findByLastNameOrderByCreatedDateDesc(String lastName){
		return personDao.findByLastNameOrderByCreatedDateDesc(lastName);
	}


	public Iterable<Person> findByLastNameOrFirstName(String lastName,String firstName){
		return personDao.findByLastNameOrFirstName(lastName, firstName);
	}


	public Iterable<Person> findByAgeLessThanEqual(Integer personAge){
		return personDao.findByAgeLessThanEqual(personAge);
	}

	public Iterable<Person> findByFirstNameLike(String firstName){
		return personDao.findByFirstNameLike(firstName);
	}

	public Iterable<Person> findByLastNameAndAgeLessThanEqual(String lastName,int personAge){
		return personDao.findByLastNameAndAgeLessThanEqual(lastName, personAge);
	}

	public Iterable<Person> findByCreatedDateBetween(Date startdate,Date endDate){
		return personDao.findByCreatedDateBetween(startdate, endDate);
	}
}
